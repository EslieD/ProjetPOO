import Clients.Client;
import ContratLocation.ContratLocation;
import Vehicules.Camion;
import Vehicules.ParcAutomobile;
import Vehicules.Vehicule;
import Vehicules.Voiture;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ParcAutomobile parc = new ParcAutomobile();
        List<Vehicule> vehicules = new ArrayList<>();
        List<Client> clients = new ArrayList<>();
        List<ContratLocation> contrats = new ArrayList<>();
        int choix;

        do {
            System.out.println("----- Menu Parc Automobile -----");
            System.out.println("1. Ajouter un véhicule");
            System.out.println("2. Supprimer un véhicule");
            System.out.println("3. Louer un véhicule");
            System.out.println("4. Retourner un véhicule");
            System.out.println("5. Lister les véhicules disponibles");
            System.out.println("6. Lister les véhicules indisponibles");
            System.out.println("7. Lister les Clients ");
            System.out.println("8. Lister les contrats de location de vehicule");
            System.out.println("9. Ajouter un client");
            System.out.println("10. Quitter");
            System.out.print("Votre choix : ");
            choix = scanner.nextInt();

            switch (choix) {
                case 1 -> {
                    System.out.print("Quel type de vehicule voulez-vous enregistrer ? ");
                    System.out.print("1- Voiture ");
                    System.out.print("2- Camion ");
                    int type_vehicule = scanner.nextInt();
                    if (type_vehicule == 1){
                        System.out.println("Entrez les informations de la voiture à enregistrer");
                        System.out.print("Immatriculation: ");
                        String immatriculation = scanner.next();
                        System.out.print("Marque: ");
                        String marque = scanner.next();
                        System.out.print("Modele: ");
                        String modele = scanner.next();
                        System.out.print("Année de mise en service: ");
                        int annee = scanner.nextInt();
                        System.out.print("Prix de la location par jour: ");
                        int prix = scanner.nextInt();
                        System.out.print("Nombre de place: ");
                        int nombre_place = scanner.nextInt();
                        System.out.print("Type de carburant : 1- Pour essence, 2- Diesel , 3- Electronique");
                        int type_carburant = scanner.nextInt();
                        parc.ajouterVehicule(new Voiture(immatriculation, marque, modele, annee, prix, nombre_place, type_carburant), vehicules);
                        System.out.println("Véhicule ajouté avec succès.");
                    } else if (type_vehicule == 2) {
                        System.out.println("Entrez les informations du camion à enregistrer");
                        System.out.print("Immatriculation: ");
                        String immatriculation = scanner.next();
                        System.out.print("Marque: ");
                        String marque = scanner.next();
                        System.out.print("Modele: ");
                        String modele = scanner.next();
                        System.out.print("Année de mise en service: ");
                        int annee = scanner.nextInt();
                        System.out.print("Prix de la location par jour: ");
                        int prix = scanner.nextInt();
                        System.out.print("Capacité de chargement: ");
                        int capacite_chargement = scanner.nextInt();
                        System.out.print("Nombre d'essieux du camion : ");
                        int nombre_essieux = scanner.nextInt();
                        parc.ajouterVehicule(new Camion(immatriculation, marque, modele, annee, prix, capacite_chargement, nombre_essieux), vehicules);
                        System.out.println("Véhicule ajouté avec succès.");
                    }
                }

                case 2 -> {
                    System.out.print("Immatriculation du véhicule à supprimer: ");
                    String immatriculation = scanner.next();
                    parc.supprimerVehicule(immatriculation, vehicules);
                }

                case 3 -> {
                    System.out.print("Immatriculation du véhicule à louer: ");
                    String immatriculation = scanner.next();
                    System.out.print("Nom du client: ");
                    String nomClient = scanner.next();
                    System.out.print("Pendant combien de jour vous voulez louer le vehicule: ");
                    int nombre_jours = scanner.nextInt();
                    parc.louerVehicule(immatriculation, nomClient, LocalDate.now(), LocalDate.now().plusDays(nombre_jours), contrats, vehicules, clients);
                }
                case 4 -> {
                    System.out.print("Immatriculation du véhicule à retourner: ");
                    String immatriculation = scanner.next();
                    parc.retournerVehicule(immatriculation, vehicules);
                }

                case 5 -> parc.listerVehiculesDisponibles(vehicules);
                case 6 -> parc.listerVehiculesinDisponibles(vehicules);
                case 7 -> parc.listerClients(clients);
                case 8 -> parc.listerContrats(contrats);

                case 9 -> {
                    System.out.print("Nom du client: ");
                    String nom = scanner.next();
                    System.out.print("prenoms du client: ");
                    String prenoms = scanner.next();
                    System.out.print("Numero du permis du client: ");
                    String numeroPermis = scanner.next();
                    System.out.print("Numero de telephone du client: ");
                    String telephone = scanner.next();
                    parc.ajouterClient(new Client(nom, prenoms, numeroPermis, telephone), clients);
                    System.out.println("Client ajouté avec succès.");
                }

                default -> System.out.println("Option invalide.");
            }
        } while (choix != 10);

        scanner.close();
    }

}