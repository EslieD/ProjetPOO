package Exception;

public class NombrePlacesInvalideException extends Exception {
    public NombrePlacesInvalideException(String message) {
        super(message);
    }
}
