package Exception;

public class CapaciteChargementInvalideException extends Exception {
    public CapaciteChargementInvalideException(String message) {
        super(message);
    }
}
