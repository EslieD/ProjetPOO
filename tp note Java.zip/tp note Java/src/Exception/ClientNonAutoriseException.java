package Exception;

public class ClientNonAutoriseException extends Exception {
    public ClientNonAutoriseException(String message) {
        super(message);
    }
}

