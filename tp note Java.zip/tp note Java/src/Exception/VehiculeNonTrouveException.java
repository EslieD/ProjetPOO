package Exception;

public class VehiculeNonTrouveException extends Exception {
    public VehiculeNonTrouveException(String message) {
        super(message);
    }
}
