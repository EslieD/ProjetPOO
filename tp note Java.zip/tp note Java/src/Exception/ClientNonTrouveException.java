package Exception;

public class ClientNonTrouveException extends Exception {
    public ClientNonTrouveException(String message) {
        super(message);
    }
}
