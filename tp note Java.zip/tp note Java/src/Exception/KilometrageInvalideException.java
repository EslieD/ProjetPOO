package Exception;

public class KilometrageInvalideException extends Exception {
    public KilometrageInvalideException(String message) {
        super(message);
    }
}
