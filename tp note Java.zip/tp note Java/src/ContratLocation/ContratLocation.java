package ContratLocation;


import Clients.Client;
import Vehicules.Vehicule;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ContratLocation {
    Client client;
    Vehicule vehicule;
    LocalDate dateDebut;
    LocalDate dateFin;

    public ContratLocation(Client client, Vehicule vehicule, LocalDate dateDebut, LocalDate dateFin) {
        this.client = client;
        this.vehicule = vehicule;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }

    public double calculerPrixTotal() {
        long jours = ChronoUnit.DAYS.between(dateDebut, dateFin);
        return vehicule.calculerPrixLocation((int) jours);
    }

    @Override
    public String toString() {
        return "Contrat{" +
                "Client = " + client +  // Appelle toString() de Client
                ", Immatriculation du véhicule = '" + vehicule.getImmatriculation() + '\'' +
                ", Date de début = '" + dateDebut + '\'' +
                ", Date de fin = '" + dateFin + '\'' +
                ", Coût total = " + calculerPrixTotal();
    }

}

