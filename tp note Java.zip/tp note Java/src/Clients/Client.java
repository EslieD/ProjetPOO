package Clients;

import ContratLocation.ContratLocation;

import java.util.ArrayList;
import java.util.List;

public class Client {
    String nom;
    String prenom;
    String numeroPermis;
    String telephone;
    List<ContratLocation> contrats = new ArrayList<>();

    public Client(String nom, String prenom, String numeroPermis, String telephone) {
        this.nom = nom;
        this.prenom = prenom;
        this.numeroPermis = numeroPermis;
        this.telephone = telephone;
    }

    public void ajouterContrat(ContratLocation contrat) {
        contrats.add(contrat);
    }

    public List<ContratLocation> getContrats() {
        return contrats;
    }

    public String getNom() {
        return this.nom;
    }

    public String getNumeroPermis() {
        return this.numeroPermis;
    }

    public void setNumeroTelephone(String nouveauNumero) {
        this.telephone = nouveauNumero;
    }

    @Override
    public String toString() {
        return
                "Nom = '" + nom + '\'' +
                        ", Prénoms = '" + prenom + '\'' +
                        ", Téléphone = '" + telephone + '\'' +
                        ", Numéro de permis = '" + numeroPermis + '\'' ;
    }
}
