package Vehicules;

public abstract class Vehicule implements Louable {
    String immatriculation;
    String marque;
    String modele;
    int anneeMiseEnService;
    double prixParJour;
    boolean statut;
    int kilometrage;

    public Vehicule(String immatriculation, String marque, String modele, int anneeMiseEnService, double prixParJour) {
        this.immatriculation = immatriculation;
        this.marque = marque;
        this.modele = modele;
        this.anneeMiseEnService = anneeMiseEnService;
        this.prixParJour = prixParJour;
        this.statut = true;
    }

    public abstract double calculerPrixLocation(int jours);

    public boolean isDisponible() {
        return statut;
    }

    public void louer() {
        statut = false;
    }

    public void retourner() {
        statut = true;
    }

    public String getImmatriculation() {
        return immatriculation;
    }

    public void setKilometrage(int nouveauKilometrage) {
        this.kilometrage = nouveauKilometrage;
    }

    public void setImmatriculation(String  nouvelleImmatriculation) {
        this.immatriculation = nouvelleImmatriculation;
    }

    // Getters et Setters pour les autres attributs, si nécessaire
}
