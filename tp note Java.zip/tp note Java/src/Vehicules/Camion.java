package Vehicules;

public class Camion extends Vehicule {
    int capaciteDeChargement;
    int nombreDEssieux;

    public Camion(String immatriculation, String marque, String modele, int anneeMiseEnService, double prixParJour,
                  int capaciteDeChargement, int nombreDEssieux) {
        super(immatriculation, marque, modele, anneeMiseEnService, prixParJour);
        this.capaciteDeChargement = capaciteDeChargement;
        this.nombreDEssieux = nombreDEssieux;
    }

    @Override
    public double calculerPrixLocation(int jours) {
        return jours * super.prixParJour;
    }

    @Override
    public String toString() {
        return
                "Immatriculation = '" + immatriculation + '\'' +
                        ", Marque = '" + marque + '\'' +
                        ", Modèle = '" + modele + '\'' +
                        ", Année = " + anneeMiseEnService +
                        ", Prix par jour = " + prixParJour +
                        ", Capacité de chargement = " + capaciteDeChargement +
                        ", Nombre d'essieux = " + nombreDEssieux
                ;
    }

    public int getCapaciteChargement() {
        return capaciteDeChargement;
    }
}
