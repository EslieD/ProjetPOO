package Vehicules;

public interface Louable {
    void louer();

    void retourner();
}

