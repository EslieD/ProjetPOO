package Vehicules;

public class Voiture extends Vehicule {
    int nombreDePlaces;
    int typeDeCarburant;

    public Voiture(String immatriculation, String marque, String modele, int anneeMiseEnService, double prixParJour,
                   int nombreDePlaces, int typeDeCarburant) {
        super(immatriculation, marque, modele, anneeMiseEnService, prixParJour);
        this.nombreDePlaces = nombreDePlaces;
        this.typeDeCarburant = typeDeCarburant;
    }

    @Override
    public double calculerPrixLocation(int jours) {
        return jours * super.prixParJour;
    }

    @Override
    public String toString() {
        return
                "Immatriculation = '" + immatriculation + '\'' +
                        ", Marque = '" + marque + '\'' +
                        ", Modèle = '" + modele + '\'' +
                        ", Année = " + anneeMiseEnService +
                        ", Prix par jour = " + prixParJour +
                        ", Nombre de places = " + nombreDePlaces +
                        ", Type de carburant = " + typeDeCarburant
                ;
    }

    public int getNombreDePlaces() {
        return nombreDePlaces;
    }
}
