package Vehicules;

import Clients.Client;
import ContratLocation.ContratLocation;

import java.time.LocalDate;
import java.util.List;

public class ParcAutomobile {

    // Ajouter un véhicule
    public void ajouterVehicule(Vehicule vehicule, List<Vehicule> vehicules) {
        if (trouverVehicule(vehicule.getImmatriculation(), vehicules) == null){
            vehicules.add(vehicule);
        }else {
            System.out.println("Un vehicule avec cette immatriculation est deja enregistré.");
        }
    }

    // Supprimer un véhicule
    public void supprimerVehicule(String immatriculation, List<Vehicule> vehicules) {
        Vehicule vehicule = trouverVehicule(immatriculation, vehicules);
        if (vehicule != null) {
            vehicules.remove(vehicule);
            System.out.println("Véhicule supprimé avec succès.");
        } else {
            System.out.println("Véhicule non trouvé.");
        }
    }

    // Modifier un véhicule (exemple: kilométrage)
    public void modifierVehicule(String immatriculation, int nouveauKilometrage, List<Vehicule> vehicules) {
        Vehicule vehicule = trouverVehicule(immatriculation, vehicules);
        if (vehicule != null) {
            vehicule.setKilometrage(nouveauKilometrage);
            System.out.println("Véhicule modifié avec succès.");
        } else {
            System.out.println("Véhicule non trouvé.");
        }
    }

    // Ajouter un client
    public void ajouterClient(Client client, List<Client> clients) {
        if (trouverClient(client.getNumeroPermis(), clients) == null){
            clients.add(client);
        }else {
            System.out.println("Un client avec cet numero de permis est deja enregistré.");
        }

    }

    // Supprimer un client
    public void supprimerClient(String nom, List<Client> clients) {
        Client client = trouverClient(nom, clients);
        if (client != null) {
            clients.remove(client);
            System.out.println("Client supprimé avec succès.");
        } else {
            System.out.println("Client non trouvé.");
        }
    }

    // Modifier un client (exemple : numéro de téléphone)
    public void modifierClient(String nom, String nouveauNumero, List<Client> clients) {
        Client client = trouverClient(nom, clients);
        if (client != null) {
            client.setNumeroTelephone(nouveauNumero);
            System.out.println("Client modifié avec succès.");
        } else {
            System.out.println("Client non trouvé.");
        }
    }

    // Louer un véhicule à un client
    public void louerVehicule(String immatriculation, String nomClient, LocalDate dateDebut, LocalDate dateFin, List<ContratLocation> contrats,List<Vehicule> vehicules, List<Client> clients) {
        Vehicule vehicule = trouverVehicule(immatriculation, vehicules);
        Client client = trouverClient(nomClient, clients);

        if (vehicule != null && client != null) {
            vehicule.louer();
            ContratLocation contrat = new ContratLocation(client, vehicule, dateDebut, dateFin);
            double prix_total = contrat.calculerPrixTotal();
            client.ajouterContrat(contrat);
            contrats.add(contrat);
            System.out.println("Véhicule loué avec succès.");
            System.out.println("ça vous coutera " + prix_total + " F CFA");
        } else {
            System.out.println("Véhicule ou client introuvable.");
        }
    }

    // Retourner un véhicule
    public void retournerVehicule(String immatriculation, List<Vehicule> vehicules) {
        Vehicule vehicule = trouverVehicule(immatriculation, vehicules);
        if (vehicule != null) {
            vehicule.retourner();
            System.out.println("Véhicule retourné avec succès.");
        } else {
            System.out.println("Véhicule non trouvé.");
        }
    }

    // Lister les véhicules disponibles
    public void listerVehiculesDisponibles(List<Vehicule> vehicules) {
        System.out.println("Véhicules disponibles :");
        for (Vehicule vehicule : vehicules) {
            if (vehicule.isDisponible()) {
                System.out.println(vehicule);
            }
        }
    }

    // Lister les véhicules disponibles
    public void listerVehiculesinDisponibles(List<Vehicule> vehicules) {
        System.out.println("Véhicules disponibles :");
        for (Vehicule vehicule : vehicules) {
            if (!vehicule.isDisponible()) {
                System.out.println(vehicule);
            }
        }
    }

    // Lister les contrats de location
    public void listerContrats(List<ContratLocation> contrats) {
        System.out.println("Liste des contrats de location :");
        for (ContratLocation contrat : contrats) {
            System.out.println(contrat);
        }
    }

    // Lister tous les clients
    public void listerClients(List<Client> clients) {
        System.out.println("Liste des clients :");
        for (Client client : clients) {
            System.out.println(client);
        }
    }

    // Trouver un véhicule par immatriculation
    public Vehicule trouverVehicule(String immatriculation, List<Vehicule> vehicules) {
        for (Vehicule vehicule : vehicules) {
            if (vehicule.getImmatriculation().equals(immatriculation)) {
                return vehicule;
            }
        }
        return null;
    }

    // Trouver un client par nom
    public Client trouverClient(String nom, List<Client> clients) {
        for (Client client : clients) {
            if (client.getNom().equals(nom)) {
                return client;
            }
        }
        return null;
    }
}
